// Initialize transactions array from localStorage or empty array
let transactions = JSON.parse(localStorage.getItem('transactions')) || [];

// DOM Elements
const balanceEl = document.getElementById('balance');
const incomeAmountEl = document.getElementById('income-amount');
const expenseAmountEl = document.getElementById('expense-amount');
const transactionListEl = document.getElementById('transaction-list');
const transactionForm = document.getElementById('transaction-form');
const descriptionInput = document.getElementById('description');
const amountInput = document.getElementById('amount');
const categoryInput = document.getElementById('category');
const dateInput = document.getElementById('date');
const typeInput = document.getElementById('type');
const searchInput = document.getElementById('search-input');
const categoryFilter = document.getElementById('category-filter');
const monthlyIncomeEl = document.getElementById('monthly-income');
const monthlyExpenseEl = document.getElementById('monthly-expense');
const reportModal = document.getElementById('report-modal');
const generateReportBtn = document.getElementById('generate-report');
const closeModalBtn = document.querySelector('.close-modal');
const reportPeriod = document.getElementById('report-period');
const customDateRange = document.getElementById('custom-date-range');
const startDate = document.getElementById('start-date');
const endDate = document.getElementById('end-date');
const downloadReportBtn = document.getElementById('download-report');
const deductFromIncomeCheckbox = document.getElementById('deductFromIncome');

// Set default date to today
dateInput.valueAsDate = new Date();

// Add transaction
function addTransaction(e) {
    e.preventDefault();

    const description = descriptionInput.value;
    const amount = parseFloat(amountInput.value);
    const category = categoryInput.value;
    const date = dateInput.value;
    const type = typeInput.value;
    const deductFromIncome = deductFromIncomeCheckbox.checked;

    if (description.trim() === '' || isNaN(amount) || amount <= 0) {
        alert('Please enter valid description and amount');
        return;
    }

    const transaction = {
        id: Date.now(),
        description,
        amount: type === 'expense' ? -amount : amount,
        category,
        date,
        type
    };

    if (type === 'expense' && deductFromIncome) {
        // Find the latest income transaction
        const latestIncome = transactions
            .filter(t => t.type === 'income')
            .sort((a, b) => new Date(b.date) - new Date(a.date))[0];

        if (latestIncome) {
            // Create a new income transaction with negative amount
            const deductionTransaction = {
                id: Date.now() + 1,
                description: `Deduction from ${description}`,
                amount: -amount,
                category: 'Deduction',
                date,
                type: 'income'
            };
            transactions.push(deductionTransaction);
        } else {
            alert('No income available to deduct from');
            return;
        }
    }

    transactions.push(transaction);
    updateLocalStorage();
    updateValues();
    renderTransactions();
    transactionForm.reset();
    dateInput.valueAsDate = new Date();
    deductFromIncomeCheckbox.checked = false;
}

// Render transactions
function renderTransactions() {
    transactionListEl.innerHTML = '';
    transactions.forEach(transaction => {
        const sign = transaction.amount < 0 ? '-' : '+';
        const item = document.createElement('li');
        item.classList.add(transaction.amount < 0 ? 'expense' : 'income');

        const date = new Date(transaction.date).toLocaleDateString('en-PK', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });

        item.innerHTML = `
            <div class="transaction-info">
                <div class="transaction-description">${transaction.description}</div>
                <div class="transaction-category">${transaction.category}</div>
                <div class="transaction-date">${date}</div>
            </div>
            <span class="transaction-amount ${transaction.amount < 0 ? 'expense' : 'income'}">
                ${sign}PKR ${Math.abs(transaction.amount).toFixed(2)}
            </span>
            <button class="delete-btn" onclick="removeTransaction(${transaction.id})">x</button>
        `;

        transactionListEl.appendChild(item);
    });
}

// Generate random ID
function generateID() {
    return Math.floor(Math.random() * 100000000);
}

// Update the balance, income and expense
function updateValues() {
    const amounts = transactions.map(transaction => {
        if (transaction.type === 'expense') {
            return -transaction.amount;
        }
        return transaction.amount;
    });

    const total = amounts.reduce((acc, item) => (acc += item), 0).toFixed(2);
    const income = amounts
        .filter(item => item > 0)
        .reduce((acc, item) => (acc += item), 0)
        .toFixed(2);
    const expense = amounts
        .filter(item => item < 0)
        .reduce((acc, item) => (acc += item), 0)
        .toFixed(2);

    balanceEl.textContent = `PKR ${total}`;
    incomeAmountEl.textContent = `PKR ${income}`;
    expenseAmountEl.textContent = `PKR ${Math.abs(expense)}`;

    // Update monthly summary
    updateMonthlySummary();
}

// Update monthly summary
function updateMonthlySummary() {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();

    const monthlyTransactions = transactions.filter(transaction => {
        const transactionDate = new Date(transaction.date);
        return transactionDate.getMonth() === currentMonth && 
               transactionDate.getFullYear() === currentYear;
    });

    const monthlyIncome = monthlyTransactions
        .filter(transaction => transaction.amount > 0)
        .reduce((acc, transaction) => acc + transaction.amount, 0)
        .toFixed(2);

    const monthlyExpense = monthlyTransactions
        .filter(transaction => transaction.amount < 0)
        .reduce((acc, transaction) => acc + Math.abs(transaction.amount), 0)
        .toFixed(2);

    monthlyIncomeEl.innerText = `PKR ${monthlyIncome}`;
    monthlyExpenseEl.innerText = `PKR ${monthlyExpense}`;
}

// Remove transaction by ID
function removeTransaction(id) {
    transactions = transactions.filter(transaction => transaction.id !== id);
    updateLocalStorage();
    init();
}

// Update local storage transactions
function updateLocalStorage() {
    localStorage.setItem('transactions', JSON.stringify(transactions));
}

// Filter transactions
function filterTransactions() {
    const searchTerm = searchInput.value.toLowerCase();
    const categoryValue = categoryFilter.value;

    const filteredTransactions = transactions.filter(transaction => {
        const matchesSearch = transaction.description.toLowerCase().includes(searchTerm);
        const matchesCategory = categoryValue === 'all' || transaction.category === categoryValue;
        return matchesSearch && matchesCategory;
    });

    transactionListEl.innerHTML = '';
    filteredTransactions.forEach(addTransactionDOM);
}

// Report Generation Functions
function showReportModal() {
    reportModal.style.display = 'block';
    updateReportContent();
}

function closeReportModal() {
    reportModal.style.display = 'none';
}

function downloadReport() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(20);
    doc.text('Financial Report', 105, 20, { align: 'center' });
    
    // Add date
    doc.setFontSize(12);
    doc.text(`Generated on: ${new Date().toLocaleDateString('en-PK')}`, 105, 30, { align: 'center' });
    
    // Add period
    const period = reportPeriod.value;
    doc.text(`Period: ${period.replace('-', ' ').toUpperCase()}`, 105, 40, { align: 'center' });
    
    // Get filtered transactions
    const periodData = getFilteredTransactions();
    const { transactions: filteredTransactions, totalIncome, totalExpense, categoryTotals } = periodData;
    
    // Add summary section
    doc.setFontSize(16);
    doc.text('Summary', 20, 60);
    
    // Add summary details
    doc.setFontSize(12);
    doc.text(`Total Income: PKR ${totalIncome}`, 20, 70);
    doc.text(`Total Expense: PKR ${totalExpense}`, 20, 80);
    doc.text(`Net Balance: PKR ${(totalIncome - totalExpense).toFixed(2)}`, 20, 90);
    
    // Add category breakdown
    doc.setFontSize(16);
    doc.text('Category Breakdown', 20, 110);
    
    // Create category table
    const categoryData = Object.entries(categoryTotals).map(([category, amount]) => [
        category.charAt(0).toUpperCase() + category.slice(1),
        `PKR ${amount.toFixed(2)}`
    ]);
    
    doc.autoTable({
        startY: 120,
        head: [['Category', 'Amount']],
        body: categoryData,
        theme: 'grid',
        headStyles: { fillColor: [108, 99, 255] }
    });
    
    // Add transactions section
    doc.setFontSize(16);
    doc.text('Transactions', 20, doc.lastAutoTable.finalY + 20);
    
    // Create transactions table
    const transactionData = filteredTransactions.map(transaction => [
        new Date(transaction.date).toLocaleDateString('en-PK'),
        transaction.description,
        transaction.category,
        transaction.amount < 0 ? 'Expense' : 'Income',
        `PKR ${Math.abs(transaction.amount).toFixed(2)}`
    ]);
    
    doc.autoTable({
        startY: doc.lastAutoTable.finalY + 30,
        head: [['Date', 'Description', 'Category', 'Type', 'Amount']],
        body: transactionData,
        theme: 'grid',
        headStyles: { fillColor: [108, 99, 255] }
    });
    
    // Save the PDF
    doc.save(`expense-report-${period}-${new Date().toISOString().split('T')[0]}.pdf`);
}

function getFilteredTransactions() {
    const period = reportPeriod.value;
    let start, end;

    switch(period) {
        case 'this-month':
            start = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
            end = new Date();
            break;
        case 'last-month':
            start = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
            end = new Date(new Date().getFullYear(), new Date().getMonth(), 0);
            break;
        case 'this-year':
            start = new Date(new Date().getFullYear(), 0, 1);
            end = new Date();
            break;
        case 'custom':
            start = new Date(startDate.value);
            end = new Date(endDate.value);
            break;
    }

    const filteredTransactions = transactions.filter(transaction => {
        const transactionDate = new Date(transaction.date);
        return transactionDate >= start && transactionDate <= end;
    });

    const totalIncome = filteredTransactions
        .filter(t => t.amount > 0)
        .reduce((acc, t) => acc + t.amount, 0)
        .toFixed(2);

    const totalExpense = filteredTransactions
        .filter(t => t.amount < 0)
        .reduce((acc, t) => acc + Math.abs(t.amount), 0)
        .toFixed(2);

    const categoryTotals = {};
    filteredTransactions.forEach(transaction => {
        const category = transaction.category;
        if (!categoryTotals[category]) {
            categoryTotals[category] = 0;
        }
        categoryTotals[category] += Math.abs(transaction.amount);
    });

    return {
        transactions: filteredTransactions,
        totalIncome,
        totalExpense,
        categoryTotals
    };
}

function updateReportContent() {
    const { transactions: filteredTransactions, totalIncome, totalExpense, categoryTotals } = getFilteredTransactions();

    // Update summary content
    const summaryContent = document.getElementById('report-summary-content');
    summaryContent.innerHTML = `
        <div class="summary-item">
            <h4>Total Income</h4>
            <p>PKR ${totalIncome}</p>
        </div>
        <div class="summary-item">
            <h4>Total Expense</h4>
            <p>PKR ${totalExpense}</p>
        </div>
        <div class="summary-item">
            <h4>Net Balance</h4>
            <p>PKR ${(totalIncome - totalExpense).toFixed(2)}</p>
        </div>
        <div class="category-breakdown">
            <h4>Category Breakdown</h4>
            ${Object.entries(categoryTotals)
                .map(([category, amount]) => `
                    <div class="category-item">
                        <span>${category}</span>
                        <span>PKR ${amount.toFixed(2)}</span>
                    </div>
                `).join('')}
        </div>
    `;

    // Update transactions content
    const transactionsContent = document.getElementById('report-transactions-content');
    transactionsContent.innerHTML = filteredTransactions
        .map(transaction => `
            <div class="report-transaction-item">
                <div class="transaction-info">
                    <div class="transaction-description">${transaction.description}</div>
                    <div class="transaction-category">${transaction.category}</div>
                    <div class="transaction-date">${new Date(transaction.date).toLocaleDateString('en-PK')}</div>
                </div>
                <div class="transaction-amount ${transaction.amount < 0 ? 'expense' : 'income'}">
                    ${transaction.amount < 0 ? '-' : '+'}PKR ${Math.abs(transaction.amount).toFixed(2)}
                </div>
            </div>
        `).join('');
}

// Event Listeners
transactionForm.addEventListener('submit', addTransaction);
searchInput.addEventListener('input', filterTransactions);
categoryFilter.addEventListener('change', filterTransactions);
generateReportBtn.addEventListener('click', showReportModal);
closeModalBtn.addEventListener('click', closeReportModal);
reportPeriod.addEventListener('change', () => {
    customDateRange.classList.toggle('hidden', reportPeriod.value !== 'custom');
    updateReportContent();
});
startDate.addEventListener('change', updateReportContent);
endDate.addEventListener('change', updateReportContent);
downloadReportBtn.addEventListener('click', downloadReport);

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    if (e.target === reportModal) {
        closeReportModal();
    }
});

// Init app
function init() {
    transactionListEl.innerHTML = '';
    transactions.forEach(addTransactionDOM);
    updateValues();
}

// Initialize app
init(); 