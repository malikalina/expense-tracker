const express=require("express")
const app=express()
app.set('view engine', 'ejs')
app.listen(3000,()=>{
    console.log("Express Server is running on port 3000")
})

app.get('/',(req,res)=>{
    res.send("<h1>Server is abc</h1>")
})

app.get('/about',(req,res)=>{
    res.send("<h1>About</h1>")
})

app.get('/about/user',(req,res)=>{
    res.send("<h1>User Info</h1>")
})

app.get('/user', (req, res) => {
    res.render(`user`)
  })
  app.get('/download', (req, res) => {
    res.download(__dirname+ `./assignment.pdf`)
  })
